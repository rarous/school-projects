/**
 * AdresarKontaktu.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package CvutSemestralniPrace;

public interface AdresarKontaktu extends javax.xml.rpc.Service {

    // XML web service for realization semestral work from X36Alg
    public java.lang.String getAdresarKontaktuSoapAddress();

    public CvutSemestralniPrace.AdresarKontaktuSoap getAdresarKontaktuSoap() throws javax.xml.rpc.ServiceException;

    public CvutSemestralniPrace.AdresarKontaktuSoap getAdresarKontaktuSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
