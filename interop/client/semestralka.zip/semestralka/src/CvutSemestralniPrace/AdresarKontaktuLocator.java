/**
 * AdresarKontaktuLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package CvutSemestralniPrace;

public class AdresarKontaktuLocator
    extends org.apache.axis.client.Service
    implements CvutSemestralniPrace.AdresarKontaktu
{

  // XML web service for realization semestral work from X36Alg

  // Use to get a proxy class for AdresarKontaktuSoap
  private final java.lang.String AdresarKontaktuSoap_address =
      "http://rarous.aspweb.cz/sp/kontakt.asmx";

  public java.lang.String getAdresarKontaktuSoapAddress()
  {
    return AdresarKontaktuSoap_address;
  }

  // The WSDD service name defaults to the port name.
  private java.lang.String AdresarKontaktuSoapWSDDServiceName =
      "AdresarKontaktuSoap";

  public java.lang.String getAdresarKontaktuSoapWSDDServiceName()
  {
    return AdresarKontaktuSoapWSDDServiceName;
  }

  public void setAdresarKontaktuSoapWSDDServiceName(java.lang.String name)
  {
    AdresarKontaktuSoapWSDDServiceName = name;
  }

  public CvutSemestralniPrace.AdresarKontaktuSoap getAdresarKontaktuSoap() throws
      javax.xml.rpc.ServiceException
  {
    java.net.URL endpoint;
    try
    {
      endpoint = new java.net.URL(AdresarKontaktuSoap_address);
    }
    catch (java.net.MalformedURLException e)
    {
      throw new javax.xml.rpc.ServiceException(e);
    }
    return getAdresarKontaktuSoap(endpoint);
  }

  public CvutSemestralniPrace.AdresarKontaktuSoap getAdresarKontaktuSoap(java.
      net.URL portAddress) throws javax.xml.rpc.ServiceException
  {
    try
    {
      CvutSemestralniPrace.AdresarKontaktuSoapStub _stub = new
          CvutSemestralniPrace.AdresarKontaktuSoapStub(portAddress, this);
      _stub.setPortName(getAdresarKontaktuSoapWSDDServiceName());
      return _stub;
    }
    catch (org.apache.axis.AxisFault e)
    {
      return null;
    }
  }

  /**
   * For the given interface, get the stub implementation.
   * If this service has no port for the given interface,
   * then ServiceException is thrown.
   */
  public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.
      xml.rpc.ServiceException
  {
    try
    {
      if (CvutSemestralniPrace.AdresarKontaktuSoap.class.isAssignableFrom(
          serviceEndpointInterface))
      {
        CvutSemestralniPrace.AdresarKontaktuSoapStub _stub = new
            CvutSemestralniPrace.AdresarKontaktuSoapStub(new java.net.URL(
            AdresarKontaktuSoap_address), this);
        _stub.setPortName(getAdresarKontaktuSoapWSDDServiceName());
        return _stub;
      }
    }
    catch (java.lang.Throwable t)
    {
      throw new javax.xml.rpc.ServiceException(t);
    }
    throw new javax.xml.rpc.ServiceException(
        "There is no stub implementation for the interface:  " +
        (serviceEndpointInterface == null ? "null" :
         serviceEndpointInterface.getName()));
  }

  /**
   * For the given interface, get the stub implementation.
   * If this service has no port for the given interface,
   * then ServiceException is thrown.
   */
  public java.rmi.Remote getPort(javax.xml.namespace.QName portName,
                                 Class serviceEndpointInterface) throws javax.
      xml.rpc.ServiceException
  {
    if (portName == null)
    {
      return getPort(serviceEndpointInterface);
    }
    String inputPortName = portName.getLocalPart();
    if ("AdresarKontaktuSoap".equals(inputPortName))
    {
      return getAdresarKontaktuSoap();
    }
    else
    {
      java.rmi.Remote _stub = getPort(serviceEndpointInterface);
      ( (org.apache.axis.client.Stub) _stub).setPortName(portName);
      return _stub;
    }
  }

  public javax.xml.namespace.QName getServiceName()
  {
    return new javax.xml.namespace.QName("urn:CvutSemestralniPrace",
                                         "AdresarKontaktu");
  }

  private java.util.HashSet ports = null;

  public java.util.Iterator getPorts()
  {
    if (ports == null)
    {
      ports = new java.util.HashSet();
      ports.add(new javax.xml.namespace.QName("AdresarKontaktuSoap"));
    }
    return ports.iterator();
  }

}
