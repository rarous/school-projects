/**
 * AdresarKontaktuSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package CvutSemestralniPrace;

public interface AdresarKontaktuSoap extends java.rmi.Remote {

    // Add new address into database
    public void ulozKontakt(CvutSemestralniPrace.Kontakt kontakt) throws java.rmi.RemoteException;

    // Read address from database - lastname search
    public CvutSemestralniPrace.Kontakt nactiKontakt(java.lang.String prijmeni) throws java.rmi.RemoteException;

    // Return all contacts from database
    public CvutSemestralniPrace.ArrayOfKontakt nactiKontakty() throws java.rmi.RemoteException;

    // Delete address from database
    public void smazKontakt(int id) throws java.rmi.RemoteException;
}
