/**
 * ArrayOfKontakt.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package CvutSemestralniPrace;

public class ArrayOfKontakt  implements java.io.Serializable {
    private CvutSemestralniPrace.Kontakt[] kontakt;

    public ArrayOfKontakt() {
    }

    public CvutSemestralniPrace.Kontakt[] getKontakt() {
        return kontakt;
    }

    public void setKontakt(CvutSemestralniPrace.Kontakt[] kontakt) {
        this.kontakt = kontakt;
    }

    public CvutSemestralniPrace.Kontakt getKontakt(int i) {
        return kontakt[i];
    }

    public void setKontakt(int i, CvutSemestralniPrace.Kontakt value) {
        this.kontakt[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ArrayOfKontakt)) return false;
        ArrayOfKontakt other = (ArrayOfKontakt) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.kontakt==null && other.getKontakt()==null) || 
             (this.kontakt!=null &&
              java.util.Arrays.equals(this.kontakt, other.getKontakt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getKontakt() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getKontakt());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getKontakt(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ArrayOfKontakt.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:CvutSemestralniPrace", "ArrayOfKontakt"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kontakt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:CvutSemestralniPrace", "Kontakt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:CvutSemestralniPrace", "Kontakt"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
