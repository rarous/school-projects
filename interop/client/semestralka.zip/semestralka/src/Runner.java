import CvutSemestralniPrace.*;
import sugar.*;
import org.apache.axis.client.Service;
import java.net.URL;
import org.apache.axis.AxisFault;
import java.rmi.RemoteException;
import java.net.MalformedURLException;
import javax.xml.rpc.ServiceException;

/**
 * <h1>Interoperabilita SOAP</h1>
 * <p>Author: Ales Roubicek</p>
 * <p>Description: Test komunikace webove sluzby a klienta,
 * ktere nejsou na stejne platforme a ve stejnem prostredi.</p>
 * @author Ales Roubicek [rarous]
 * @version 1.0
 */

public class Runner {
  public static void main(String[] args) throws AxisFault, RemoteException
      , MalformedURLException, RemoteException, ServiceException,
      MalformedURLException, RemoteException {

    /* Nastaveni proxy serververu pro pristup k protokolu HTTP */
    //System.setProperty("http.proxyHost", "proxy.felk.cvut.cz");
    //System.setProperty("http.proxyPort", "80");

    int volba = 0;
    /* Tisk hlavicky programu */
    Sys.pln("Interoperabilita SOAP");
    Sys.pln("Semestralni prace");
    Sys.pln("Client k XML webove sluzbe");

    /* vytvoreni menu a rozpoznni vybrane funkce */
    do
    {
      Sys.pln();
      Sys.pln("Menu:");
      Sys.pln("\t0. konec programu");
      Sys.pln("\t1. Novy kontakt");
      Sys.pln("\t2. Vyhledat kontakt");
      Sys.pln("\t3. Vypsat kontakty");
      Sys.pln("\t4. Smazat kontakt");
      Sys.pln("_____________________________");
      Sys.p("Vase volba: ");
      volba = Sys.readInt();
      switch (volba) {
        case 1:
          Sys.pln();
          Sys.pln("Zvoleno: Novy kontakt");
          novyKontakt();
          break;
        case 2:
          Sys.pln();
          Sys.pln("Zvoleno: Najdi kontakt");
          najdiKontakt();
          break;
        case 3:
          Sys.pln();
          Sys.pln("Zvoleno: Vypsat kontakty");
          nactiKontakty();
          break;
        case 4:
          Sys.pln();
          Sys.pln("Zvoleno: Smazat kontakt");
          smazKontakt();
          break;
        default:
          volba = 0;
      }
    }while(volba != 0);
  }
  /* metoda tvorici rozhranni pro vytvoreni noveho kontaktu */
  static void novyKontakt() throws AxisFault, RemoteException
      , MalformedURLException, AxisFault, ServiceException {
    Kontakt kontakt = new Kontakt();
    /* adresa webove sluzby */
    URL sluzba = new URL("http://rarous.aspweb.cz/sp/kontakt.asmx");
    /* vytvoreni komunikacniho rozhrani se sluzbou */
    AdresarKontaktuLocator lokator = new AdresarKontaktuLocator();
    AdresarKontaktuSoap adresar = lokator.getAdresarKontaktuSoap(sluzba);
    /* rozhanni pro vstup dat */
    Sys.p("Zadejte jmeno: ");
    kontakt.setJmeno(Sys.readLine());
    Sys.p("Zadejte prijmeni: ");
    kontakt.setPrijmeni(Sys.readLine());
    Sys.p("Zadejte email: ");
    kontakt.setEmail(Sys.readLine());
    Sys.p("Zadejte telefon: ");
    kontakt.setTelefon(Sys.readInt());
    Sys.p("Zadejte www: ");
    kontakt.setWww(Sys.readLine());
    Sys.p("Zadejte icq: ");
    kontakt.setIcq(Sys.readInt());
    /*  zavolani vzdalene metody */
    adresar.ulozKontakt(kontakt);
    Sys.pln("Kontakt ulozen");
  }
  /* metoda tvorici rozhranni pro vyhledani kontaktu */
  static void najdiKontakt() throws AxisFault, RemoteException
      , ServiceException, MalformedURLException {
    /* adresa webove sluzby */
    URL sluzba = new URL("http://rarous.aspweb.cz/sp/kontakt.asmx");
    /* vytvoreni komunikacniho rozhrani se sluzbou */
    AdresarKontaktuLocator lokator = new AdresarKontaktuLocator();
    AdresarKontaktuSoap adresar = lokator.getAdresarKontaktuSoap(sluzba);
    /* nacteni hledaneho prijmeni */
    Sys.p("Zadejte hledane prijmeni: ");
    /*  zavolani vzdalene metody */
    Kontakt kontakt = adresar.nactiKontakt(Sys.readLine());

    Sys.pln();
    Sys.pln(kontakt.toString());
    Sys.pln();
  }

  static void nactiKontakty() throws AxisFault, RemoteException
      , ServiceException, MalformedURLException {
    URL sluzba = new URL("http://rarous.aspweb.cz/sp/kontakt.asmx");
    AdresarKontaktuLocator lokator = new AdresarKontaktuLocator();
    AdresarKontaktuSoap adresar = lokator.getAdresarKontaktuSoap(sluzba);

    ArrayOfKontakt kontakt = adresar.nactiKontakty();

    Sys.pln();
    for(int i=0; i < kontakt.getKontakt().length; i++) Sys.pln(kontakt.getKontakt(i).toString());
    Sys.pln();

  }

  static void smazKontakt() throws MalformedURLException, ServiceException,
      RemoteException {
    URL sluzba = new URL("http://rarous.aspweb.cz/sp/kontakt.asmx");
    AdresarKontaktuLocator lokator = new AdresarKontaktuLocator();
    AdresarKontaktuSoap adresar = lokator.getAdresarKontaktuSoap(sluzba);

    Sys.p("Zdejte id kontaktu: ");
    adresar.smazKontakt(Sys.readInt());
    Sys.pln("Kontakt smazan");
  }

}