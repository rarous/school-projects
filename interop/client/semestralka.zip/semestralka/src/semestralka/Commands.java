package semestralka;

import java.net.*;
import java.rmi.*;
import javax.xml.rpc.*;

import CvutSemestralniPrace.*;
import java.rmi.RemoteException;

/**
 * <p>Title: Semestralni prace</p>
 * <p>Description: Podp�rn� t��da pro odd�len� komunikace se slu�bou a GUI.</p>
 * <p>Company: CVUT FEL</p>
 * @author Ale� Roub��ek
 * @version 1.5
 */

public class Commands
{
  URL sluzba;
  AdresarKontaktuLocator lokator;
  AdresarKontaktuSoap adresar;
  /**
   * <p>Konstruktor s parametrem String url, pripojuje se ke sluzbe s timto url</p>
   * @param url
   * @throws MalformedURLException
   * @throws ServiceException
   */
  public Commands(String url) throws MalformedURLException
      , ServiceException
  {
    sluzba = new URL(url);
    lokator = new AdresarKontaktuLocator();
    adresar = lokator.getAdresarKontaktuSoap(sluzba);
  }
  /**
   * <p>Funkce pro ukladani objektu typu Kontakt do DB,
   * vola metodu ulozKontakt(Kontakt k) proxy tridy.</p>
   * @param kontakt
   * @return boolean
   * @throws RemoteException
   */
  boolean ulozitKontakt(Kontakt kontakt) throws RemoteException
  {
    /* ulozeni kontaktu pomoci sluzby */
    adresar.ulozKontakt(kontakt);
    return true;
  }
  /**
   * <p>Nacte pomoci proxy tridy Kontakt podle prijmeni z DB</p>
   * @param prijmeni
   * @return Kontakt
   * @throws RemoteException
   */
  Kontakt nacistKontakt(String prijmeni) throws RemoteException
  {
    return adresar.nactiKontakt(prijmeni);
  }
  /**
   * <p>Vraci pole vsech Kontaktu z DB.</p>
   * @return
   * @throws RemoteException
   */
  Kontakt[] nacistKontakty() throws RemoteException
  {
    return adresar.nactiKontakty().getKontakt();
  }
  /**
   * <p>Smaze kontakt pomoci proxy tridy z DB. Maze podle id kontaktu</p>
   * @param id
   * @return
   * @throws RemoteException
   */
  boolean smazatKontakt(int id) throws RemoteException
  {
    adresar.smazKontakt(id);
    return true;
  }
}