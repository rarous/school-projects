package semestralka;

import java.net.*;
import java.rmi.*;
import javax.xml.rpc.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import CvutSemestralniPrace.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;

/**
 * <p>Title: <b>Interoperabilita SOAP II</b></p>
 * <p>Description: Test komunikace webove sluzby a klienta,
 * ktere nejsou na stejne platforme a ve stejnem prostredi.</p>
 * <p>Company: CVUT FEL</p>
 * @author Ale� Roub��ek [rarous]
 * @version 1.5
 */

public class GuiRunner
    extends JFrame
{
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtJmeno = new JTextField();
  JTextField txtPrijmeni = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField txtEmail = new JTextField();
  JTextField txtWww = new JTextField();
  JTextField txtTelefon = new JTextField();
  JTextField txtIcq = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JButton btnUlozit = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton btnReset = new JButton();

  Kontakt kontakt;
  Kontakt[] kontakty;
  JPanel jPanel4 = new JPanel();
  JLabel jLabel7 = new JLabel();
  JTextField txtAdresaSluzby = new JTextField();
  JCheckBox chbProxy = new JCheckBox();
  JLabel jLabel8 = new JLabel();
  JTextField txtProxyServer = new JTextField();
  JLabel jLabel9 = new JLabel();
  JTextField txtProxyPort = new JTextField();
  JButton btnNacist = new JButton();
  VerticalFlowLayout verticalFlowLayout3 = new VerticalFlowLayout();
  JPanel jPanel5 = new JPanel();
  JLabel jLabel10 = new JLabel();
  JTextField txtHledat = new JTextField();
  JButton btnHledat = new JButton();
  JLabel lblMessage = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  XYLayout xYLayout1 = new XYLayout();
  XYLayout xYLayout3 = new XYLayout();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel11 = new JLabel();
  JTextField txtIdDelete = new JTextField();
  JButton btnDelete = new JButton();
  XYLayout xYLayout2 = new XYLayout();
  JPanel pnlSearchResult = new JPanel();
  JPanel pnlAllResult = new JPanel();
  JPanel jPanel7 = new JPanel();
  XYLayout xYLayout4 = new XYLayout();
  JPanel jPanel8 = new JPanel();
  XYLayout xYLayout5 = new XYLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  /**
   * Implementace zav�r�n� okna a spu�t�n� jbInit</p>
   */
  public GuiRunner()
  {
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        System.exit(0);
      }
    });
    try
    {
      jbInit();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  /**
   * <p>Aplikace se zap�n� bez parametr�</p>
   * @param args
   */
  public static void main(String[] args)
  {
    GuiRunner form1 = new GuiRunner();
    form1.setSize(645,440);
    form1.show();
  }

  /**
   * <p>Konstrukce GUI - generovan� designerem</p>
   * @throws java.lang.Exception
   */
  private void jbInit() throws Exception
  {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    jLabel1.setText("Jm�no:");
    this.setResizable(true);
    this.setTitle("Interoperabilita SOAP");
    this.getContentPane().setLayout(borderLayout1);
    jLabel2.setText("P��jmen�:");
    txtJmeno.setMaximumSize(new Dimension(25, 120));
    txtJmeno.setMargin(new Insets(0, 0, 0, 0));
    txtJmeno.setText("");
    txtPrijmeni.setMaximumSize(new Dimension(25, 120));
    txtPrijmeni.setText("");
    jLabel3.setText("E-mail:");
    txtEmail.setMaximumSize(new Dimension(25, 120));
    txtEmail.setText("@");
    txtWww.setMaximumSize(new Dimension(25, 120));
    txtWww.setText("http://");
    txtTelefon.setMaximumSize(new Dimension(25, 120));
    txtTelefon.setText("");
    txtIcq.setMaximumSize(new Dimension(25, 120));
    txtIcq.setText("");
    jLabel4.setText("Web:");
    jLabel5.setText("Telefon:");
    jLabel6.setText("ICQ:");
    jPanel1.setLayout(xYLayout1);
    btnUlozit.setText("Ulo�it");
    btnUlozit.addActionListener(new frmSemestral_btnUlozit_actionAdapter(this));
    jPanel3.setLayout(flowLayout1);
    btnReset.setText("Reset");
    btnReset.addActionListener(new frmSemestral_btnReset_actionAdapter(this));
    chbProxy.setHorizontalAlignment(SwingConstants.LEADING);
    chbProxy.setText("Pou��t proxy server");
    chbProxy.setVerticalAlignment(SwingConstants.CENTER);
    jLabel8.setText("Proxy server: ");
    jPanel4.setLayout(xYLayout3);
    jLabel7.setText("Adresa slu�by: ");
    txtAdresaSluzby.setText("http://rarous.aspweb.cz/sp/kontakt.asmx");
    chbProxy.setText("Pou��t proxy server");
    chbProxy.addActionListener(new frmSemestral_chbProxy_actionAdapter(this));
    jLabel8.setText("Proxy server: ");
    txtProxyServer.setText("proxy.felk.cvut.cz");
    jLabel9.setText("Proxy port: ");
    txtProxyPort.setText("80");
    txtProxyPort.setHorizontalAlignment(SwingConstants.RIGHT);
    btnNacist.setMaximumSize(new Dimension(64, 25));
    btnNacist.setHorizontalAlignment(SwingConstants.CENTER);
    btnNacist.setHorizontalTextPosition(SwingConstants.TRAILING);
    btnNacist.setSelected(true);
    btnNacist.setText("Na��st kontakty");
    btnNacist.setVerticalAlignment(SwingConstants.CENTER);
    btnNacist.addActionListener(new frmSemestral_btnNacist_actionAdapter(this));
    jPanel2.setLayout(verticalFlowLayout3);
    jLabel10.setText("P��jmen�:");
    txtHledat.setText("");
    jPanel5.setLayout(verticalFlowLayout1);
    btnHledat.setText("Hledat");
    btnHledat.addActionListener(new frmSemestral_btnHledat_actionAdapter(this));

    lblMessage.setForeground(Color.black);
    lblMessage.setRequestFocusEnabled(true);
    lblMessage.setText("Interoperabilita SOAP II");
    flowLayout1.setAlignment(FlowLayout.LEFT);
    jLabel11.setText("Id kontaktu :");
    txtIdDelete.setSelectionStart(11);
    txtIdDelete.setText("0");
    btnDelete.setText("Smazat");
    btnDelete.addActionListener(new GuiRunner_btnDelete_actionAdapter(this));
    jPanel6.setLayout(xYLayout2);
    jPanel7.setLayout(xYLayout4);
    jPanel8.setLayout(xYLayout5);
    jPanel6.setBackground(Color.lightGray);
    jPanel6.setBorder(titledBorder2);
    jPanel7.setBorder(titledBorder4);
    jPanel1.add(jLabel1,  new XYConstraints(5, 5, 385, -1));
    jPanel1.add(txtJmeno,   new XYConstraints(5, 25, 120, -1));
    jPanel1.add(jLabel2,  new XYConstraints(5, 49, 385, -1));
    jPanel1.add(txtPrijmeni,   new XYConstraints(5, 69, 120, -1));
    jPanel1.add(jLabel3,  new XYConstraints(5, 95, 385, -1));
    jPanel1.add(txtEmail,   new XYConstraints(5, 115, 150, -1));
    jPanel1.add(jLabel4,  new XYConstraints(5, 141, 385, -1));
    jPanel1.add(txtWww,   new XYConstraints(5, 161, 150, -1));
    jPanel1.add(jLabel5,  new XYConstraints(5, 187, 385, -1));
    jPanel1.add(txtTelefon,   new XYConstraints(5, 207, 100, -1));
    jPanel1.add(jLabel6,  new XYConstraints(5, 233, 385, -1));
    jPanel1.add(txtIcq,   new XYConstraints(5, 253, 100, -1));
    jPanel1.add(jPanel3,  new XYConstraints(395, 5, 385, -1));
    jPanel3.add(btnUlozit, null);
    jPanel3.add(btnReset, null);
    this.getContentPane().add(lblMessage,  BorderLayout.SOUTH);
    jPanel7.add(txtHledat, new XYConstraints(68, 2, 99, -1));
    jPanel7.add(btnHledat, new XYConstraints(173, 0, -1, -1));
    jPanel7.add(jLabel10,  new XYConstraints(9, 4, -1, -1));
    jPanel5.add(jPanel7, null);
    jPanel5.add(pnlSearchResult, null);
    jPanel4.add(jLabel7,  new XYConstraints(5, 5, 385, -1));
    jPanel4.add(txtAdresaSluzby,    new XYConstraints(5, 25, 230, -1));
    jPanel4.add(chbProxy,  new XYConstraints(5, 51, 385, -1));
    jPanel4.add(jLabel8,  new XYConstraints(5, 79, 385, -1));
    jPanel4.add(txtProxyServer,   new XYConstraints(5, 99, 150, -1));
    jPanel4.add(jLabel9,  new XYConstraints(5, 125, 385, -1));
    jPanel4.add(txtProxyPort,     new XYConstraints(5, 145, 25, -1));
    jPanel6.add(jLabel11,   new XYConstraints(0, 0, 71, 25));
    jPanel6.add(txtIdDelete,   new XYConstraints(70, 0, 41, 25));
    jPanel6.add(btnDelete,        new XYConstraints(118, 0, 78, 22));
    jPanel2.add(jPanel8, null);
    jPanel8.add(btnNacist,   new XYConstraints(0, 5, -1, -1));
    jPanel2.add(jPanel6, null);
    jPanel2.add(pnlAllResult, null);
    this.getContentPane().add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(jPanel4, "Nastaven�");
    jTabbedPane1.add(jPanel1, "Nov� kontakt");
    jTabbedPane1.add(jPanel5, "Hledat kontakt");
    jTabbedPane1.add(jPanel2, "V�pis kontakt�");
  }

  /**
   * <p>Vymaz�n� obsahu fomul��ovych prvk�</p>
   * @param e
   */
  void btnReset_actionPerformed(ActionEvent e)
  {
    txtJmeno.setText("");
    txtPrijmeni.setText("");
    txtEmail.setText("@");
    txtWww.setText("http://");
    txtTelefon.setText("");
    txtIcq.setText("");
  }

  /**
   * <p>Star� se o odesl�n� dat slu�b� pomoc� proxy t��dy</p>
   * @param e
   */
  void btnUlozit_actionPerformed(ActionEvent e)
  {
    kontakt = new Kontakt();
    try
    {
      lblMessage.setForeground(Color.BLUE);
      lblMessage.setText("ukladam ...");
      Commands controler = new Commands(txtAdresaSluzby.getText());
      kontakt.setJmeno(txtJmeno.getText());
      kontakt.setPrijmeni(txtPrijmeni.getText());
      kontakt.setEmail(txtEmail.getText());
      kontakt.setWww(txtWww.getText());
      kontakt.setTelefon(Integer.parseInt(txtTelefon.getText()));
      kontakt.setIcq(Integer.parseInt(txtIcq.getText()));
      controler.ulozitKontakt(kontakt);
      lblMessage.setText("ulozeno");
    }
    catch (MalformedURLException ex)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Spatna adresa sluzby");
      System.err.print(ex);
    }
    catch (RemoteException ex1)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex1);
    }
    catch (ServiceException ex2)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex2);
    }
  }

  /**
   * <p>Nastavuje pou�it� proxy serveru k http p�enosu</p>
   * @param e
   */
  void chbProxy_actionPerformed(ActionEvent e)
  {
    if (chbProxy.isSelected())
    {
      System.setProperty("http.proxyHost", txtProxyServer.getText());
      System.setProperty("http.proxyPort", txtProxyPort.getText());
    }
    else
    {
      System.setProperty("http.proxyHost", "");
      System.setProperty("http.proxyPort", "");
    }
  }

  void btnNacist_actionPerformed(ActionEvent e)
  {
    Commands controler = null;
    try
    {
      lblMessage.setForeground(Color.BLUE);
      lblMessage.setText("nacitam ...");
      KontaktControl textik = new KontaktControl();
      pnlAllResult.removeAll();
      pnlAllResult.add(textik, null);
      controler = new Commands(txtAdresaSluzby.getText());
      Kontakt[] kontakty = controler.nacistKontakty();
      StringBuffer sb = new StringBuffer();
      for(int i = 0; i < kontakty.length; i++)
      {
        textik = new KontaktControl();
        textik.setAll(kontakty[i]);
        pnlAllResult.add(textik, null);
      }
      lblMessage.setText("");
    }
    catch (MalformedURLException ex)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Spatna adresa sluzby");
      System.err.print(ex);
    }
    catch (RemoteException ex1)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex1);
    }
    catch (ServiceException ex2)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex2);
    }
  }

  void btnHledat_actionPerformed(ActionEvent e) {
    Commands controler = null;
    try
    {
      lblMessage.setForeground(Color.BLUE);
      lblMessage.setText("hledam ...");
      controler = new Commands(txtAdresaSluzby.getText());
      kontakt = controler.nacistKontakt(txtHledat.getText());
      KontaktControl textik = new KontaktControl();
      pnlSearchResult.removeAll();
      pnlSearchResult.add(textik, null);
      textik = new KontaktControl();
      textik.setAll(kontakt);
      pnlSearchResult.add(textik, null);
      lblMessage.setText("");
    }
    catch (MalformedURLException ex)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Spatna adresa sluzby");
      System.err.print(ex);
    }
    catch (RemoteException ex1)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex1);
    }
    catch (ServiceException ex2)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex2);
    }

  }

  void btnDelete_actionPerformed(ActionEvent e) {
    Commands controler = null;
    try
    {
      lblMessage.setForeground(Color.BLUE);
      lblMessage.setText("mazu ...");
      controler = new Commands(txtAdresaSluzby.getText());
      controler.smazatKontakt(Integer.parseInt(txtIdDelete.getText()));

    }
    catch (MalformedURLException ex)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Spatna adresa sluzby");
      System.err.print(ex);
    }
    catch (RemoteException ex1)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex1);
    }
    catch (ServiceException ex2)
    {
      lblMessage.setForeground(Color.RED);
      lblMessage.setText("Chyba pri komunikaci se sluzbou");
      System.err.print(ex2);
    }
    btnNacist_actionPerformed(e); // znovu nacte z db kontakty
  }
}

class frmSemestral_btnReset_actionAdapter
    implements java.awt.event.ActionListener
{
  GuiRunner adaptee;

  frmSemestral_btnReset_actionAdapter(GuiRunner adaptee)
  {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e)
  {
    adaptee.btnReset_actionPerformed(e);
  }
}

class frmSemestral_btnUlozit_actionAdapter
    implements java.awt.event.ActionListener
{
  GuiRunner adaptee;

  frmSemestral_btnUlozit_actionAdapter(GuiRunner adaptee)
  {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e)
  {
    adaptee.btnUlozit_actionPerformed(e);
  }
}

class frmSemestral_chbProxy_actionAdapter
    implements java.awt.event.ActionListener
{
  GuiRunner adaptee;

  frmSemestral_chbProxy_actionAdapter(GuiRunner adaptee)
  {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e)
  {
    adaptee.chbProxy_actionPerformed(e);
  }
}

class frmSemestral_btnNacist_actionAdapter
    implements java.awt.event.ActionListener
{
  GuiRunner adaptee;

  frmSemestral_btnNacist_actionAdapter(GuiRunner adaptee)
  {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e)
  {
    adaptee.btnNacist_actionPerformed(e);
  }
}

class frmSemestral_btnHledat_actionAdapter implements java.awt.event.ActionListener {
  GuiRunner adaptee;

  frmSemestral_btnHledat_actionAdapter(GuiRunner adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnHledat_actionPerformed(e);
  }
}

class GuiRunner_btnDelete_actionAdapter implements java.awt.event.ActionListener {
  GuiRunner adaptee;

  GuiRunner_btnDelete_actionAdapter(GuiRunner adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnDelete_actionPerformed(e);
  }
}