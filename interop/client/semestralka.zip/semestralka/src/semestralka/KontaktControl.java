package semestralka;

import java.awt.*;
import javax.swing.*;
import CvutSemestralniPrace.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: Semestralni prace</p>
 * <p>Description: Interoperabilita SOAP II</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CVUT FEL</p>
 * @author Ale� Roub��ek
 * @version 1.5
 */

public class KontaktControl extends Panel
{
  JLabel lblId = new JLabel();
  JLabel lblJmeno = new JLabel();
  JLabel lblPrijmeni = new JLabel();
  JLabel lblEmail = new JLabel();
  JLabel lblTelefon = new JLabel();
  JLabel lblWww = new JLabel();
  JLabel lblIcq = new JLabel();
  GridLayout gridLayout1 = new GridLayout();
  Border border1;
  XYLayout xYLayout1 = new XYLayout();

  public KontaktControl()
  {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }
  private void jbInit() throws Exception {
    border1 = BorderFactory.createLineBorder(Color.gray,1);
    lblId.setBorder(border1);
    lblId.setText("Id");
    lblJmeno.setBorder(border1);
    lblJmeno.setHorizontalAlignment(SwingConstants.LEADING);
    lblJmeno.setText("Jmeno");
    lblPrijmeni.setBorder(border1);
    lblPrijmeni.setHorizontalAlignment(SwingConstants.LEADING);
    lblPrijmeni.setText("Prijmeni");
    lblEmail.setBorder(border1);
    lblEmail.setHorizontalAlignment(SwingConstants.LEADING);
    lblEmail.setText("E-mail");
    lblTelefon.setBorder(border1);
    lblTelefon.setHorizontalAlignment(SwingConstants.RIGHT);
    lblTelefon.setText("Telefon");
    lblWww.setBorder(border1);
    lblWww.setHorizontalAlignment(SwingConstants.LEADING);
    lblWww.setText("Web");
    lblIcq.setBorder(border1);
    lblIcq.setHorizontalAlignment(SwingConstants.RIGHT);
    lblIcq.setText("ICQ");
    this.setLayout(xYLayout1);
    this.setBackground(Color.white);
    this.add(lblId,  new XYConstraints(0, 0, 20, -1));
    this.add(lblJmeno,  new XYConstraints(20, 0, 80, -1));
    this.add(lblPrijmeni,  new XYConstraints(100, 0, 100, -1));
    this.add(lblEmail,  new XYConstraints(200, 0, 150, -1));
    this.add(lblWww,  new XYConstraints(350, 0, 120,-1));
    this.add(lblTelefon,  new XYConstraints(470, 0, 75, -1));
    this.add(lblIcq,  new XYConstraints(545, 0, 75, -1));
  }

  void setId(int id)
  {
    lblId.setText(new Integer(id).toString());
  }
  void setJmeno(String jmeno)
  {
    lblJmeno.setText(jmeno);
  }
  void setPrijmeni(String prijmeni)
  {
    lblPrijmeni.setText(prijmeni);
  }
  void setEmail(String email)
  {
    lblEmail.setText(email);
  }
  void setTelefon(int telefon)
  {
    lblTelefon.setText(new Integer(telefon).toString());
  }
  void setWww(String url)
  {
    lblWww.setText(url);
  }
  void setIcq(int icq)
  {
    lblIcq.setText(new Integer(icq).toString());
  }
  void setAll(Kontakt kontakt)
  {
    this.setId(kontakt.getId());
    this.setJmeno(kontakt.getJmeno());
    this.setPrijmeni(kontakt.getPrijmeni());
    this.setEmail(kontakt.getEmail());
    this.setTelefon(kontakt.getTelefon());
    this.setWww(kontakt.getWww());
    this.setIcq(kontakt.getIcq());
  }
}